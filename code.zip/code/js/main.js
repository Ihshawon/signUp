// typer js
var typed5 = new Typed('.heading-primary__typo', {
    strings: ["simple","easy","creative"],
    typeSpeed:60,
    backSpeed: 40,
    cursorChar: '_',
    shuffle: true,
    smartBackspace: true,
    loop: true,



  });




  // owl carousel js

  var owl = $('.owl-carousel');
  owl.owlCarousel({
      
      loop:true,
      autoplay:true,
      autoplayTimeout:3000,
      nav:false,
      center:true,
      items :9,
        responsiveClass:true,
      responsive:{
          0:{
              items:1,
              nav:false
          },
          600:{
              items:3,
              nav:false
          },
          900:{
            items:5,
            nav:false
        },
          1000:{
              items:5,
              nav:false
          
          }
      }
   
 
  });


  // Scroll reveal

window.sr = ScrollReveal();

sr.reveal('.animate-left',{

     
    origin:'left',
    duration:1000,
    distance:'25rem',
    delay:300,

});

sr.reveal('.animate-right',{

     
    origin:'right',
    duration:1000,
    distance:'25rem',
    delay:600,

});

sr.reveal('.animate-top',{

     
    origin:'top',
    duration:1000,
    distance:'25rem',
    delay:600,

});

sr.reveal('.animate-bottom',{

     
    origin:'bottom',
    duration:1000,
    distance:'20rem',
    delay:600,

});

    